/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package informacionPersonal;

/**
 *
 * @author Sebastian Estevez
 */
public class numerosPareConCicloWhile {
    public static void main(String[] args) {

        int num = 2;

        while (num <= 100) {
            System.out.println(num);
            num = num + 2;
        }
    }
}
    

