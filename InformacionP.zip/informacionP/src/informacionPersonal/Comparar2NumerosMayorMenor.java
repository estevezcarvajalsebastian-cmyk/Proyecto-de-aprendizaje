/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package informacionPersonal;
import java.util.Scanner;

/**
 *
 * @author Sebastian Estevez
 */
public class Comparar2NumerosMayorMenor {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el primer número: ");
        int numero1 = scanner.nextInt();

        System.out.print("Ingrese el segundo número: ");
        int numero2 = scanner.nextInt();

        if (numero1 > numero2) {
            System.out.println("El mayor es: " + numero1);
            System.out.println("El menor es: " + numero2);
        } else if (numero2 > numero1) {
            System.out.println("El mayor es: " + numero2);
            System.out.println("El menor es: " + numero1);
        } else {
            System.out.println("Los dos números son iguales.");
        }

        scanner.close();
    }
}
    

