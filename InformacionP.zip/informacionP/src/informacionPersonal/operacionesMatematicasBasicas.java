/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package informacionPersonal;

/**
 *
 * @author Sebastian Estevez
 */
public class operacionesMatematicasBasicas {
    public static void main(String[] args) {
        double suma = 0;
        double resta = 0;
        double multiplicacion = 0;
        double division = 0;
        double n1 = 15;
        double n2 = 10;
        double resultado = 0;
        
        resultado = n1 + n2;
        System.out.println("la suma es: " + resultado);
        
        resultado = n1 - n2;
        System.out.println("la resta es: " + resultado);
        
        resultado = n1 * n2;
        System.out.println("la multiplicacion es: " + resultado);
        
        resultado = n1 / n2;
        System.out.println("la division es: " + resultado);
        
    }
    
}
